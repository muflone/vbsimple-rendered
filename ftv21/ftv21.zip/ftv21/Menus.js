var mnuSelected = '';
var subMnuSelected = '';
function showMenu(menu){
	hideMenu(mnuSelected);
	document.getElementById(menu).style.visibility = 'visible';
	mnuSelected = menu;
}
function hideMenu(menu){
	if(mnuSelected!='')
		document.getElementById(menu).style.visibility = 'hidden';
}
function showSubMenu(menu){
	hideSubMenu(subMnuSelected);
	document.getElementById(menu).style.visibility = 'visible';
	subMnuSelected = menu;
}
function hideSubMenu(menu){
	if(subMnuSelected!='')
		document.getElementById(menu).style.visibility = 'hidden';
}
