CREATE TABLE ElencoCD (
  id      NUMBER,
  nome    VARCHAR(128),
  data    DATETIME
)
GO

CREATE TABLE Files (
  id      NUMBER,
  cd      NUMBER,
  nome    VARCHAR(128),
  spazio  NUMBER,
  descr   MEMO  
)
GO