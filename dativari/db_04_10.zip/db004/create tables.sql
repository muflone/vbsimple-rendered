CREATE TABLE ElencoCD(
	id   NUMERIC,
	nome CHAR(128),
	data DATE
)
GO

CREATE UNIQUE INDEX pk_cd ON ElencoCD(id)
GO

CREATE TABLE Files(
	id     NUMERIC,
	cd     NUMERIC,
	nome   CHAR(128),
	spazio NUMERIC,
	descr  MEMO
)
GO

CREATE UNIQUE INDEX pk_files ON Files(id)
GO

CREATE INDEX fk_cd ON Files(cd)
GO