CREATE TABLE ElencoCD (
  id      NUMERIC(10, 0),
  nome    CHAR(128),
  data    DATE
)
GO

CREATE UNIQUE INDEX pk_cd ON ElencoCD(id)
GO

CREATE TABLE Files (
  id      NUMERIC(10),
  cd      NUMERIC(10),
  nome    CHAR(128),
  spazio  NUMERIC(19),
  descr   MEMO
)
GO

CREATE UNIQUE INDEX pk_files ON Files(id)
GO

CREATE INDEX fk_cd ON Files(cd)
GO