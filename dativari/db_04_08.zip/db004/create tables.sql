CREATE TABLE ElencoCD (
  id      I       NOT NULL PRIMARY KEY,
  nome    C(128)  NOT NULL,
  data    T       NOT NULL
)
GO

CREATE TABLE Files (
  id      I       NOT NULL PRIMARY KEY,
  cd      I       NOT NULL,
  nome    C(128)  NOT NULL,
  spazio  I       NOT NULL,
  descr   M       NULL
)
GO
