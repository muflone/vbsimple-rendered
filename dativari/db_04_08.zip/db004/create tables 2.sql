CREATE DATABASE db004
GO

USE db004
GO

CREATE TABLE ElencoCD (
  id      INTEGER,
  nome    CHAR(128),
  data    DATE
)
GO

CREATE UNIQUE INDEX pk_id ON ElencoCD(id)
GO

CREATE TABLE Files (
  id      INTEGER,
  cd      INTEGER,
  nome    CHAR(128),
  spazio  INTEGER,
  descr   MEMO
)
GO

CREATE UNIQUE INDEX pk_files ON Files(id)
GO

CREATE INDEX fk_cd ON Files(cd)
GO
