CREATE TABLE ElencoCD (
  id      SHORT,
  nome    ALPHANUMERIC(128),
  data    TIMESTAMP,
  CONSTRAINT ElencoCD PRIMARY KEY(id) 
)
GO

CREATE TABLE Files (
  id      SHORT,
  cd      SHORT,
  nome    ALPHANUMERIC(128),
  spazio  LONG,
  descr   MEMO,
  CONSTRAINT Files PRIMARY KEY(id)
)
GO

CREATE INDEX cd ON Files(cd)
GO