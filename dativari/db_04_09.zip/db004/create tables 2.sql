CREATE TABLE ElencoCD (
  id      SHORT       NOT NULL,
  nome    ALPHA(128)  NOT NULL,
  data    DATE        NOT NULL
)
GO

CREATE INDEX PRIMARY ON ElencoCD(id)
GO

CREATE TABLE Files (
  id      SHORT       NOT NULL,
  cd      SHORT       NOT NULL,
  nome    ALPHA(128)  NOT NULL,
  spazio  NUMBER      NOT NULL,
  descr   MEMO
)
GO

CREATE INDEX PRIMARY ON Files(id)
GO

CREATE INDEX cd ON Files(cd)
GO