CREATE TABLE ElencoCD (
  id      SMALLINT     NOT NULL,
  nome    VARCHAR(128) NOT NULL,
  data    DATETIME     NOT NULL,
  CONSTRAINT pk_cd PRIMARY KEY(id)
)
GO

CREATE TABLE Files (
  id      SMALLINT     NOT NULL,
  cd      SMALLINT     NOT NULL,
  nome    VARCHAR(128) NOT NULL,
  spazio  INTEGER      NOT NULL,
  descr   TEXT         NULL,
  CONSTRAINT pk_files PRIMARY KEY(id),
  CONSTRAINT fk_cd FOREIGN KEY(cd) REFERENCES ElencoCD(id)
)
GO

CREATE INDEX fk_cd ON Files(cd)
GO