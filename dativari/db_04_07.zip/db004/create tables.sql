CREATE TABLE ElencoCD (
  id      SMALLINT                    NOT NULL,
  nome    CHARACTER VARYING(128)      NOT NULL,
  data    TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  CONSTRAINT pk_cd PRIMARY KEY(id)
) WITHOUT OIDS
GO

CREATE TABLE Files (
  id      SMALLINT                NOT NULL,
  cd      SMALLINT                NOT NULL,
  nome    CHARACTER VARYING(128)  NOT NULL,
  spazio  INTEGER                 NOT NULL,
  descr   TEXT                    NULL,
  CONSTRAINT pk_files PRIMARY KEY(id),
  CONSTRAINT fk_cd    FOREIGN KEY(cd) REFERENCES ElencoCD(id)
) WITHOUT OIDS
GO